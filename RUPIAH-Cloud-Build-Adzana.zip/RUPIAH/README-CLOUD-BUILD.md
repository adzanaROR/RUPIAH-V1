# RUPIAH — Cloud Build

RUPIAH is an offline Android personal finance journal.

Creator attribution: **Adzana**

## Build APK without a local laptop

1. Create/sign in to a GitHub account.
2. Create a new repository (public or private) named `RUPIAH`.
3. Upload the **contents of this project folder** so `build.gradle.kts`, `settings.gradle.kts`, `app/`, and `.github/` are at the repository root.
4. Open the repository's **Actions** tab.
5. Select **Build RUPIAH APK** and press **Run workflow**.
6. When the job finishes, open the run and download the artifact named **RUPIAH-debug-apk**.
7. Extract the ZIP and install `app-debug.apk` on Android.

The workflow builds a debug APK in GitHub's cloud environment. No Android Studio is required on your phone.
