package com.rupiah.app

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.NumberFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var balance: TextView
    private lateinit var summary: TextView
    private lateinit var empty: TextView
    private val prefs by lazy { getSharedPreferences("rupiah", Context.MODE_PRIVATE) }
    private val money = NumberFormat.getCurrencyInstance(Locale("id","ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        balance=findViewById(R.id.balance); summary=findViewById(R.id.summary); empty=findViewById(R.id.empty)
        findViewById<Button>(R.id.addButton).setOnClickListener { addTransaction() }
        refresh()
    }
    private fun addTransaction() {
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(48,0,48,0)
        val amount=EditText(this); amount.hint="Jumlah, contoh 50000"; amount.inputType=2
        val note=EditText(this); note.hint="Catatan (opsional)"
        val type=Spinner(this); type.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("Pengeluaran","Pemasukan"))
        box.addView(amount); box.addView(type); box.addView(note)
        AlertDialog.Builder(this).setTitle("Tambah transaksi").setView(box).setNegativeButton("Batal",null).setPositiveButton("Simpan"){_,_->
            val n=amount.text.toString().toLongOrNull() ?: return@setPositiveButton
            val income=type.selectedItemPosition==1
            prefs.edit().putLong("income",prefs.getLong("income",0)+(if(income)n else 0)).putLong("expense",prefs.getLong("expense",0)+(if(income)0 else n)).apply(); refresh()
        }.show()
    }
    private fun refresh(){ val i=prefs.getLong("income",0); val e=prefs.getLong("expense",0); balance.text=money.format(i-e).replace("Rp","Rp "); summary.text="Masuk ${money.format(i).replace("Rp","Rp ")}   •   Keluar ${money.format(e).replace("Rp","Rp ")}"; empty.text=if(i+e==0L) "Belum ada transaksi. Mulai catat uang masuk atau keluar." else "Data tersimpan offline di perangkat ini." }
}
